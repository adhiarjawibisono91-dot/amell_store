<?php
session_start();
include 'koneksi.php';

if (isset($_SESSION['admin'])) {
    header("location:index.php");
    exit();
}

$error = '';
if (isset($_POST['login'])) {
    $username = isset($_POST['username']) ? mysqli_real_escape_string($koneksi, trim($_POST['username'])) : '';
    $password = isset($_POST['password']) ? mysqli_real_escape_string($koneksi, trim($_POST['password'])) : '';
    
    if (!empty($username) && !empty($password)) {
        $sql = "SELECT * FROM user WHERE username='$username' AND password='$password'";
        $query = mysqli_query($koneksi, $sql);
        
        if ($query && mysqli_num_rows($query) > 0) {
            $_SESSION['admin'] = $username;
            header("location:index.php");
            exit();
        } else {
            $error = "Username atau Password salah!";
        }
    } else {
        $error = "Harap lengkapi semua bidang!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Toko Aksesoris</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }
        body {
            background: linear-gradient(135deg, #e0f2fe 0%, #bae6fd 50%, #7dd3fc 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 20px;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.92);
            backdrop-filter: blur(12px);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(56, 189, 248, 0.25);
            border: 1px solid rgba(255, 255, 255, 0.6);
            overflow: hidden;
            width: 100%;
            max-width: 420px;
            transition: transform 0.3s ease;
        }
        .login-card:hover {
            transform: translateY(-4px);
        }
        .card-header-custom {
            background: linear-gradient(135deg, #0284c7 0%, #38bdf8 100%);
            color: #ffffff;
            padding: 30px 20px;
            text-align: center;
        }
        .card-header-custom h3 {
            font-weight: 600;
            margin: 0;
            font-size: 1.6rem;
            letter-spacing: 0.5px;
        }
        .card-header-custom p {
            margin: 5px 0 0;
            font-size: 0.9rem;
            opacity: 0.9;
        }
        .icon-box {
            width: 60px;
            height: 60px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 12px;
            font-size: 1.8rem;
        }
        .card-body-custom {
            padding: 32px 28px;
        }
        .form-control {
            border-radius: 12px;
            padding: 12px 16px;
            border: 1.5px solid #e2e8f0;
            background-color: #f8fafc;
            transition: all 0.2s ease;
        }
        .form-control:focus {
            background-color: #ffffff;
            border-color: #38bdf8;
            box-shadow: 0 0 0 4px rgba(56, 189, 248, 0.15);
        }
        .btn-soft-blue {
            background: linear-gradient(135deg, #0284c7 0%, #38bdf8 100%);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 12px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            box-shadow: 0 6px 16px rgba(2, 132, 199, 0.3);
        }
        .btn-soft-blue:hover {
            background: linear-gradient(135deg, #0369a1 0%, #0284c7 100%);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(2, 132, 199, 0.4);
        }
        .input-group-text {
            border-radius: 12px 0 0 12px;
            background-color: #f1f5f9;
            border: 1.5px solid #e2e8f0;
            border-right: none;
            color: #0284c7;
        }
        .input-group .form-control {
            border-radius: 0 12px 12px 0;
        }
        .alert {
            border-radius: 12px;
            font-size: 0.9rem;
            border: none;
            background-color: #fef2f2;
            color: #dc2626;
            box-shadow: 0 2px 8px rgba(220, 38, 38, 0.1);
        }
    </style>
</head>
<body>
<div class="login-card">
    <div class="card-header-custom">
        <div class="icon-box">
            <i class="bi bi-bag-heart-fill"></i>
        </div>
        <h3>Toko Aksesoris</h3>
        <p>Silakan masuk ke akun Anda</p>
    </div>
    <div class="card-body-custom">
        <?php if(!empty($error)): ?>
            <div class="alert alert-danger d-flex align-items-center mb-4" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2 fs-5"></i>
                <div><?php echo htmlspecialchars($error); ?></div>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label class="form-label text-secondary fw-medium fs-7">Username</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
                    <input type="text" name="username" class="form-control" placeholder="Masukkan username" required autofocus>
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label text-secondary fw-medium fs-7">Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                    <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
                </div>
            </div>
            <button type="submit" name="login" class="btn btn-soft-blue w-100 py-2.5">
                <i class="bi bi-box-arrow-in-right me-2"></i>Masuk Sekarang
            </button>
        </form>
    </div>
</div>
</body>
</html>
